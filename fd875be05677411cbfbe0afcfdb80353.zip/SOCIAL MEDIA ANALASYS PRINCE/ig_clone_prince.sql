use ig_clone;
/*1.Are there any tables with duplicate or missing null values? If so, how would you handle them?*/
/*Checking for NULL Values*/
-- Users
SELECT * FROM users
WHERE username IS NULL;

-- Photos
SELECT * FROM photos
WHERE image_url IS NULL OR user_id IS NULL;

-- Comments
SELECT * FROM comments
WHERE comment_text IS NULL 
   OR user_id IS NULL 
   OR photo_id IS NULL;

-- Likes
SELECT * FROM likes
WHERE user_id IS NULL OR photo_id IS NULL;

-- Follows
SELECT * FROM follows
WHERE follower_id IS NULL OR followee_id IS NULL;

-- Tags
SELECT * FROM tags
WHERE tag_name IS NULL;

-- Photo_Tags
SELECT * FROM photo_tags
WHERE photo_id IS NULL OR tag_id IS NULL;

-- Check for Duplicate Records
SELECT username, COUNT(*) 
FROM users
GROUP BY username
HAVING COUNT(*) > 1;

-- Duplicate Photos (same user posting same image)
SELECT user_id, image_url, COUNT(*)
FROM photos
GROUP BY user_id, image_url
HAVING COUNT(*) > 1;

-- Duplicate Comments 
SELECT user_id, photo_id, comment_text, COUNT(*)
FROM comments
GROUP BY user_id, photo_id, comment_text
HAVING COUNT(*) > 1;

-- 2 objective question = What is the distribution of user activity levels (number of posts, likes, comments) across the user base?
SELECT 
    activity_level,
    COUNT(*) AS total_users
FROM (
    SELECT 
        u.id,
        u.username,
        COUNT(DISTINCT p.id) AS total_posts,
        COUNT(DISTINCT l.photo_id) AS total_likes,
        COUNT(DISTINCT c.id) AS total_comments,
        CASE 
            WHEN (COUNT(DISTINCT p.id) + 
                  COUNT(DISTINCT l.photo_id) + 
                  COUNT(DISTINCT c.id)) >= 20 THEN 'High Activity'
            WHEN (COUNT(DISTINCT p.id) + 
                  COUNT(DISTINCT l.photo_id) + 
                  COUNT(DISTINCT c.id)) >= 5 THEN 'Medium Activity'
            WHEN (COUNT(DISTINCT p.id) + 
                  COUNT(DISTINCT l.photo_id) + 
                  COUNT(DISTINCT c.id)) > 0 THEN 'Low Activity'
            ELSE 'Inactive'
        END AS activity_level
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON u.id = l.user_id
    LEFT JOIN comments c ON u.id = c.user_id
    GROUP BY u.id, u.username
) AS user_activity
GROUP BY activity_level;

-- Question 3 objective- Calculate average number of tags per post.

SELECT 
    COUNT(pt.tag_id) AS total_tags,
    COUNT(DISTINCT p.id) AS total_photos,
    ROUND(COUNT(pt.tag_id) / COUNT(DISTINCT p.id), 2) AS avg_tags_per_post
FROM photos p
LEFT JOIN photo_tags pt 
ON p.id = pt.photo_id;

-- objective 4.	Identify the top users with the highest engagement rates (likes, comments) on their posts and rank them.
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes_received,
    COUNT(DISTINCT c.id) AS total_comments_received,
    ROUND(
        (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) 
        / COUNT(DISTINCT p.id),
    2) AS engagement_rate
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY engagement_rate DESC;

-- objective 5.	Which users have the highest number of followers and followings?
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT f1.follower_id) AS total_followers,
    COUNT(DISTINCT f2.followee_id) AS total_following
FROM users u
LEFT JOIN follows f1 ON u.id = f1.followee_id
LEFT JOIN follows f2 ON u.id = f2.follower_id
GROUP BY u.id, u.username
ORDER BY total_followers DESC;

-- objective 6.	Calculate the average engagement rate (likes, comments) per post for each user.
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes_received,
    COUNT(DISTINCT c.id) AS total_comments_received,
    ROUND(
        (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) 
        / COUNT(DISTINCT p.id),
    2) AS avg_engagement_per_post
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username;

-- objective 7.	Calculate the average engagement rate (likes, comments) per post for each user.
SELECT 
    u.id,
    u.username
FROM users u
LEFT JOIN likes l 
    ON u.id = l.user_id
WHERE l.user_id IS NULL;

-- 8.	How can you leverage user-generated content (posts, hashtags, photo tags) to create more personalized and engaging ad campaigns?
SELECT 
    t.tag_name,
    COUNT(pt.photo_id) AS total_usage
FROM tags t
JOIN photo_tags pt ON t.id = pt.tag_id
GROUP BY t.tag_name
ORDER BY total_usage DESC;

-- objective 9.	Are there any correlations between user activity levels and specific content types (e.g., photos, videos, reels)? How can this information guide content creation and curation strategies?
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id) AS total_engagement
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY total_posts DESC;

-- objective 10. Calculate the total number of likes, comments, and photo tags for each user.
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes_received,
    COUNT(DISTINCT c.id) AS total_comments_received,
    COUNT(DISTINCT pt.tag_id, pt.photo_id) AS total_photo_tags
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
LEFT JOIN photo_tags pt ON p.id = pt.photo_id
GROUP BY u.id, u.username
ORDER BY u.id;

-- objective 11. Rank users based on their total engagement (likes, comments) over a month.
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes_received,
    COUNT(DISTINCT c.id) AS total_comments_received,
    (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement,
    RANK() OVER (
        ORDER BY (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) DESC
    ) AS engagement_rank
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username;

-- objective 12. Retrieve the hashtags that have been used in posts with the highest average number of likes. Use a CTE to calculate the average likes for each hashtag first.
SELECT 
    COUNT(*) AS total_users,
    COUNT(CASE WHEN p.user_id IS NULL THEN 1 END) AS inactive_users,
    COUNT(CASE WHEN p.user_id IS NOT NULL THEN 1 END) AS active_users
FROM users u
LEFT JOIN (
    SELECT DISTINCT user_id 
    FROM photos
) p ON u.id = p.user_id;

-- objective 13. Retrieve the users who have started following someone after being followed by that person.
SELECT 
    l.user_id,
    u.username,
    COUNT(DISTINCT l.photo_id) AS total_likes_given
FROM likes l
JOIN users u ON l.user_id = u.id
GROUP BY l.user_id, u.username
HAVING COUNT(DISTINCT l.photo_id) = (SELECT COUNT(*) FROM photos);

-- subjective 1.	Based on user engagement and activity levels, which users would you consider the most loyal or valuable? How would you reward or incentivize these users?
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes_received,
    COUNT(DISTINCT c.id) AS total_comments_received,
    
    (COUNT(DISTINCT l.user_id, l.photo_id) + 
     COUNT(DISTINCT c.id)) AS total_engagement,
     
    ROUND(
        (COUNT(DISTINCT l.user_id, l.photo_id) + 
         COUNT(DISTINCT c.id)) / 
        NULLIF(COUNT(DISTINCT p.id), 0), 
    2) AS engagement_per_post

FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY total_engagement DESC;

WITH user_metrics AS (
    SELECT 
        u.id,
        u.username,
        COUNT(DISTINCT p.id) AS total_posts,
        COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes_received,
        COUNT(DISTINCT c.id) AS total_comments_received,
        (COUNT(DISTINCT l.user_id, l.photo_id) + 
         COUNT(DISTINCT c.id)) AS total_engagement
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY u.id, u.username
)

SELECT *,
    CASE
        WHEN total_posts >= 8 AND total_engagement >= 500 
            THEN 'Super Creator'
        WHEN total_posts BETWEEN 3 AND 7 AND total_engagement >= 180 
            THEN 'Active & Growing'
        WHEN total_posts BETWEEN 1 AND 2 
            THEN 'Low Activity'
        ELSE 'Inactive'
    END AS user_segment
FROM user_metrics
ORDER BY total_engagement DESC;

-- 2.	For inactive users, what strategies would you recommend to re-engage them and encourage them to start posting or engaging again?
SELECT 
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.photo_id) AS total_likes_given,
    COUNT(DISTINCT c.id) AS total_comments_made
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON u.id = l.user_id
LEFT JOIN comments c ON u.id = c.user_id
GROUP BY u.id, u.username
HAVING total_posts = 0 
   AND total_likes_given = 0 
   AND total_comments_made = 0;
 -- this code is for comaparing the active users and inactive users   
   WITH user_metrics AS (
    SELECT 
        u.id,
        COUNT(DISTINCT p.id) AS total_posts,
        COUNT(DISTINCT l.photo_id) AS total_likes_given,
        COUNT(DISTINCT c.id) AS total_comments_made
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON u.id = l.user_id
    LEFT JOIN comments c ON u.id = c.user_id
    GROUP BY u.id
)

SELECT 
    CASE 
        WHEN total_posts = 0 
         AND total_likes_given = 0 
         AND total_comments_made = 0
        THEN 'Inactive Users'
        ELSE 'Active Users'
    END AS user_status,
    COUNT(*) AS total_users
FROM user_metrics
GROUP BY user_status;

-- subjective 3.	Which hashtags or content topics have the highest engagement rates? How can this information guide content strategy and ad campaigns?
WITH hashtag_metrics AS (
    SELECT 
        t.id AS tag_id,
        t.tag_name,
        COUNT(DISTINCT p.id) AS total_posts,
        COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
        COUNT(DISTINCT c.id) AS total_comments,
        (COUNT(DISTINCT l.user_id, l.photo_id) + 
         COUNT(DISTINCT c.id)) AS total_engagement
    FROM tags t
    JOIN photo_tags pt ON t.id = pt.tag_id
    JOIN photos p ON pt.photo_id = p.id
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY t.id, t.tag_name
)

SELECT *,
    ROUND(total_engagement / NULLIF(total_posts, 0), 2) AS avg_engagement_per_post
FROM hashtag_metrics
ORDER BY avg_engagement_per_post DESC;

-- subjective 4.	Are there any patterns or trends in user engagement based on demographics (age, location, gender) or posting times? How can these insights inform targeted marketing campaigns?
SELECT 
    HOUR(p.created_dat) AS posting_hour,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (COUNT(DISTINCT l.user_id, l.photo_id) + 
     COUNT(DISTINCT c.id)) AS total_engagement,
    ROUND(
        (COUNT(DISTINCT l.user_id, l.photo_id) + 
         COUNT(DISTINCT c.id)) / 
        NULLIF(COUNT(DISTINCT p.id), 0), 2
    ) AS avg_engagement_per_post
FROM photos p
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY posting_hour
ORDER BY avg_engagement_per_post DESC;

-- 5.	Based on follower counts and engagement rates, which users would be ideal candidates for influencer marketing campaigns? How would you approach and collaborate with these influencers?
WITH follower_counts AS (
    SELECT 
        followee_id AS user_id,
        COUNT(*) AS total_followers
    FROM follows
    GROUP BY followee_id
),

engagement_metrics AS (
    SELECT 
        u.id,
        u.username,
        COUNT(DISTINCT p.id) AS total_posts,
        (COUNT(DISTINCT l.user_id, l.photo_id) + 
         COUNT(DISTINCT c.id)) AS total_engagement,
        ROUND(
            (COUNT(DISTINCT l.user_id, l.photo_id) + 
             COUNT(DISTINCT c.id)) / 
            NULLIF(COUNT(DISTINCT p.id), 0), 2
        ) AS engagement_per_post
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY u.id, u.username
)

SELECT 
    e.id,
    e.username,
    f.total_followers,
    e.total_posts,
    e.engagement_per_post
FROM engagement_metrics e
JOIN follower_counts f ON e.id = f.user_id
WHERE e.total_posts > 0
ORDER BY f.total_followers DESC, e.engagement_per_post DESC;

-- 6.	Based on follower counts and engagement rates, which users would be ideal candidates for influencer marketing campaigns? How would you approach and collaborate with these influencers?
WITH user_metrics AS (
    SELECT 
        u.id,
        COUNT(DISTINCT p.id) AS total_posts,
        (COUNT(DISTINCT l.user_id, l.photo_id) + 
         COUNT(DISTINCT c.id)) AS total_engagement_received
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY u.id
)

SELECT 
    CASE
        WHEN total_posts >= 8 AND total_engagement_received >= 500
            THEN 'Super Creators'
        WHEN total_posts BETWEEN 3 AND 7
            THEN 'Active Users'
        WHEN total_posts BETWEEN 1 AND 2
            THEN 'Low Activity Users'
        ELSE 'Inactive Users'
    END AS user_segment,
    COUNT(*) AS total_users
FROM user_metrics
GROUP BY user_segment;

-- subjective 8.	How can you use user activity data to identify potential brand ambassadors or advocates who could help promote Instagram's initiatives or events?

WITH post_counts AS (
    SELECT user_id, COUNT(*) AS total_posts
    FROM photos
    GROUP BY user_id
),

likes_given AS (
    SELECT user_id, COUNT(*) AS total_likes_given
    FROM likes
    GROUP BY user_id
),

comments_given AS (
    SELECT user_id, COUNT(*) AS total_comments_made
    FROM comments
    GROUP BY user_id
),

engagement_received AS (
    SELECT p.user_id,
           COUNT(l.photo_id) + COUNT(c.id) AS total_engagement_received
    FROM photos p
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY p.user_id
)

SELECT 
    u.username,
    COALESCE(pc.total_posts, 0) AS total_posts,
    COALESCE(lg.total_likes_given, 0) AS total_likes_given,
    COALESCE(cg.total_comments_made, 0) AS total_comments_made,
    COALESCE(er.total_engagement_received, 0) AS total_engagement_received
FROM users u
LEFT JOIN post_counts pc ON u.id = pc.user_id
LEFT JOIN likes_given lg ON u.id = lg.user_id
LEFT JOIN comments_given cg ON u.id = cg.user_id
LEFT JOIN engagement_received er ON u.id = er.user_id
WHERE COALESCE(pc.total_posts,0) >= 5
  AND COALESCE(lg.total_likes_given,0) >= 100
  AND COALESCE(cg.total_comments_made,0) >= 100
ORDER BY total_engagement_received DESC;

SELECT 
    MAX(total_posts) AS max_posts,
    MAX(total_likes_given) AS max_likes_given,
    MAX(total_comments_made) AS max_comments_made
FROM (
    SELECT 
        u.id,
        COUNT(DISTINCT p.id) AS total_posts,
        COUNT(DISTINCT l.photo_id) AS total_likes_given,
        COUNT(DISTINCT c.id) AS total_comments_made
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON u.id = l.user_id
    LEFT JOIN comments c ON u.id = c.user_id
    GROUP BY u.id
) t;

WITH post_counts AS (
    SELECT user_id, COUNT(*) AS total_posts
    FROM photos
    GROUP BY user_id
),

likes_given AS (
    SELECT user_id, COUNT(*) AS total_likes_given
    FROM likes
    GROUP BY user_id
),

comments_given AS (
    SELECT user_id, COUNT(*) AS total_comments_made
    FROM comments
    GROUP BY user_id
),

engagement_received AS (
    SELECT p.user_id,
           COUNT(l.photo_id) + COUNT(c.id) AS total_engagement_received
    FROM photos p
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY p.user_id
)

SELECT 
    u.username,
    COALESCE(pc.total_posts, 0) AS total_posts,
    COALESCE(lg.total_likes_given, 0) AS total_likes_given,
    COALESCE(cg.total_comments_made, 0) AS total_comments_made,
    COALESCE(er.total_engagement_received, 0) AS total_engagement_received
FROM users u
LEFT JOIN post_counts pc ON u.id = pc.user_id
LEFT JOIN likes_given lg ON u.id = lg.user_id
LEFT JOIN comments_given cg ON u.id = cg.user_id
LEFT JOIN engagement_received er ON u.id = er.user_id
WHERE COALESCE(pc.total_posts,0) >= 5
  AND COALESCE(lg.total_likes_given,0) >= 80
ORDER BY total_engagement_received DESC;